AUTOLIKE BY MAX

        if op.type == 26:
            msg = op.message
            text = str(msg.text)
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            terminal = command(text)
            for terminal in terminal.split(" & "):
                setKey = settings["keyCommand"].title()
                if settings["setKey"] == False:
                    setKey = ''
                if msg.toType == 0 or msg.toType == 1 or msg.toType == 2:
                    if msg.toType == 0:
                        if sender != aditmadzs.profile.mid:
                            to = sender
                        else:
                            to = receiver
                    elif msg.toType == 1:
                        to = receiver
                    elif msg.toType == 2:
                        to = receiver
                    if msg.contentType == 0:
                        if to in offbot:
                            return
                    elif msg.contentType == 16:
                        if wait["checkPost"] == True:
                            try:
                                ret_ = "╭───「 Details Post 」"
                                if msg.contentMetadata["serviceType"] == "GB":
                                    contact = aditmadzs.getContact(sender)
                                    auth = "\n├≽ Penulis : {}".format(str(contact.displayName))
                                else:
                                    auth = "\n├≽ Penulis : {}".format(str(msg.contentMetadata["serviceName"]))
                                purl = "\n├≽ URL : {}".format(str(msg.contentMetadata["postEndUrl"]).replace("line://","https://line.me/R/"))
                                ret_ += auth
                                ret_ += purl
                                if "mediaOid" in msg.contentMetadata:
                                    object_ = msg.contentMetadata["mediaOid"].replace("svc=myhome|sid=h|","")
                                    if msg.contentMetadata["mediaType"] == "V":
                                        if msg.contentMetadata["serviceType"] == "GB":
                                            ourl = "\n├≽ Objek URL : https://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&{}".format(str(msg.contentMetadata["mediaOid"]))
                                            murl = "\n├≽ Media URL : https://obs-us.line-apps.com/myhome/h/download.nhn?{}".format(str(msg.contentMetadata["mediaOid"]))
                                        else:
                                            ourl = "\n├≽ Objek URL : https://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&{}".format(str(object_))
                                            murl = "\n├≽ Media URL : https://obs-us.line-apps.com/myhome/h/download.nhn?{}".format(str(object_))
                                        ret_ += murl
                                    else:
                                        if msg.contentMetadata["serviceType"] == "GB":
                                            ourl = "\n├≽ Objek URL : https://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&{}".format(str(msg.contentMetadata["mediaOid"]))
                                        else:
                                            ourl = "\n├≽ Objek URL : https://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&{}".format(str(object_))
                                    ret_ += ourl
                                if "stickerId" in msg.contentMetadata:
                                    stck = "\n├≽ Stiker : https://line.me/R/shop/detail/{}".format(str(msg.contentMetadata["packageId"]))
                                    ret_ += stck
                                if "text" in msg.contentMetadata:
                                    text = "\n├≽ Tulisan : {}".format(str(msg.contentMetadata["text"]))
                                    ret_ += text
                                ret_ += "\n╰───「 Finish 」"
                                aditmadzs.sendMessage(to, str(ret_))
                            except:
                                aditmadzs.sendMessage(to, "Post tidak valid")
                        if msg.toType in (2,1,0):
#                            purl = msg.contentMetadata["postEndUrl"].split('userMid=')[1].split('&postId=')
#                            adw = aditmadzs.likePost(purl[0], purl[1], random.choice([1001,1002,1003,1004,1005]))
                            purl = msg.contentMetadata["postEndUrl"].split('userMid=')[1].split('&postId=')
                            adw = k1.likePost(purl[0], purl[1], random.choice([1001,1002,1003,1004,1005]))
                            purl = msg.contentMetadata["postEndUrl"].split('userMid=')[1].split('&postId=')
                            adw = k2.likePost(purl[0], purl[1], random.choice([1001,1002,1003,1004,1005]))
                            purl = msg.contentMetadata["postEndUrl"].split('userMid=')[1].split('&postId=')
                            adw = k3.likePost(purl[0], purl[1], random.choice([1001,1002,1003,1004,1005]))
                            purl = msg.contentMetadata["postEndUrl"].split('userMid=')[1].split('&postId=')
                            adw = k4.likePost(purl[0], purl[1], random.choice([1001,1002,1003,1004,1005]))
                            purl = msg.contentMetadata["postEndUrl"].split('userMid=')[1].split('&postId=')
                            adw = k5.likePost(purl[0], purl[1], random.choice([1001,1002,1003,1004,1005]))
                            purl = msg.contentMetadata["postEndUrl"].split('userMid=')[1].split('&postId=')
                            adw = k6.likePost(purl[0], purl[1], random.choice([1001,1002,1003,1004,1005]))
                            purl = msg.contentMetadata["postEndUrl"].split('userMid=')[1].split('&postId=')
                            adw = k7.likePost(purl[0], purl[1], random.choice([1001,1002,1003,1004,1005]))
                            purl = msg.contentMetadata["postEndUrl"].split('userMid=')[1].split('&postId=')
                            adw = k8.likePost(purl[0], purl[1], random.choice([1001,1002,1003,1004,1005]))
                            purl = msg.contentMetadata["postEndUrl"].split('userMid=')[1].split('&postId=')
                            adw = k9.likePost(purl[0], purl[1], random.choice([1001,1002,1003,1004,1005]))
                            purl = msg.contentMetadata["postEndUrl"].split('userMid=')[1].split('&postId=')
                            adw = k10.likePost(purl[0], purl[1], random.choice([1001,1002,1003,1004,1005]))
                            purl = msg.contentMetadata["postEndUrl"].split('userMid=')[1].split('&postId=')
                            adw = k11.likePost(purl[0], purl[1], random.choice([1001,1002,1003,1004,1005]))
                            purl = msg.contentMetadata["postEndUrl"].split('userMid=')[1].split('&postId=')
                            adw = k12.likePost(purl[0], purl[1], random.choice([1001,1002,1003,1004,1005]))
                            purl = msg.contentMetadata["postEndUrl"].split('userMid=')[1].split('&postId=')
                            adw = k13.likePost(purl[0], purl[1], random.choice([1001,1002,1003,1004,1005]))
                            purl = msg.contentMetadata["postEndUrl"].split('userMid=')[1].split('&postId=')
                            adw = k14.likePost(purl[0], purl[1], random.choice([1001,1002,1003,1004,1005]))
                            purl = msg.contentMetadata["postEndUrl"].split('userMid=')[1].split('&postId=')
                            adw = k15.likePost(purl[0], purl[1], random.choice([1001,1002,1003,1004,1005]))
                            purl = msg.contentMetadata["postEndUrl"].split('userMid=')[1].split('&postId=')
                            adw = k16.likePost(purl[0], purl[1], random.choice([1001,1002,1003,1004,1005]))
                            purl = msg.contentMetadata["postEndUrl"].split('userMid=')[1].split('&postId=')
                            adw = k17.likePost(purl[0], purl[1], random.choice([1001,1002,1003,1004,1005]))
                            purl = msg.contentMetadata["postEndUrl"].split('userMid=')[1].split('&postId=')
                            adw = k18.likePost(purl[0], purl[1], random.choice([1001,1002,1003,1004,1005]))
                            purl = msg.contentMetadata["postEndUrl"].split('userMid=')[1].split('&postId=')
                            adw = k19.likePost(purl[0], purl[1], random.choice([1001,1002,1003,1004,1005]))
                            purl = msg.contentMetadata["postEndUrl"].split('userMid=')[1].split('&postId=')
                            adw = k20.likePost(purl[0], purl[1], random.choice([1001,1002,1003,1004,1005]))
                            purl = msg.contentMetadata["postEndUrl"].split('userMid=')[1].split('&postId=')
                            adw = g1.likePost(purl[0], purl[1], random.choice([1001,1002,1003,1004,1005]))
